package com.chandana.checkwifisecurity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.airbnb.lottie.LottieAnimationView;

public class MainActivity extends AppCompatActivity {

    private TextView statusText, securityStatus, recommendations, instructionText;
    private Button rescanButton, instructionsButton, showTipsButton;
    private CardView tipsCard, instructionCard;
    private LottieAnimationView wifiAnimation;
    private boolean isInstructionVisible = false;
    private boolean isTipsVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind Views
        statusText = findViewById(R.id.statusText);
        wifiAnimation = findViewById(R.id.wifiAnimation);
        securityStatus = findViewById(R.id.securityStatus);
        recommendations = findViewById(R.id.recommendations);
        rescanButton = findViewById(R.id.rescanButton);
        tipsCard = findViewById(R.id.tipsCard);
        instructionCard = findViewById(R.id.instructionCard);
        instructionsButton = findViewById(R.id.instructionsButton);
        instructionText = findViewById(R.id.instructionText);
        showTipsButton = findViewById(R.id.showTipsButton);

        tipsCard.setVisibility(View.GONE);

        recommendations.setText(
                "\uD83D\uDCCC Security Tips:\n" +
                        "- Use WPA2 or WPA3 secured networks only.\n" +
                        "- Avoid public or open WiFi for sensitive tasks.\n" +
                        "- Use VPNs like ProtonVPN, NordVPN, or Surfshark to encrypt your traffic.\n\n" +
                        "\uD83D\uDD10 A VPN encrypts your internet traffic and protects your identity even on insecure networks."
        );

        instructionText.setText(
                "\uD83D\uDCCD Location Permission Required:\n" +
                        "- Please enable location for this app in Settings > Location > App permissions.\n\n" +
                        "\uD83D\uDCE1 Why GPS is Important:\n" +
                        "- GPS is used to scan surrounding WiFi networks and assess encryption type.\n\n" +
                        "\uD83D\uDD13 If you're connected to open/public WiFi:\n" +
                        "- Use a secure VPN like ProtonVPN, NordVPN, or Surfshark.\n\n" +
                        "\uD83D\uDD10 For zero-trust secure communication, consider InstaSafe ZNTA."
        );

        startScanningAnimation();

        rescanButton.setOnClickListener(v -> {
            statusText.setText("Scanning WiFi...");
            securityStatus.setText("");
            wifiAnimation.setProgress(0f);
            wifiAnimation.playAnimation();
            wifiAnimation.removeAllAnimatorListeners();
            attachAnimationEndListener();
        });

        instructionsButton.setOnClickListener(v -> {
            isInstructionVisible = !isInstructionVisible;
            instructionCard.setVisibility(isInstructionVisible ? View.VISIBLE : View.GONE);
            instructionsButton.setText(isInstructionVisible ? "Hide Instructions" : "View Instructions");
        });

        showTipsButton.setOnClickListener(v -> {
            isTipsVisible = !isTipsVisible;
            tipsCard.setVisibility(isTipsVisible ? View.VISIBLE : View.GONE);
            showTipsButton.setText(isTipsVisible ? "Hide Tips" : "View Tips");
        });
    }

    private void startScanningAnimation() {
        wifiAnimation.setProgress(0f);
        wifiAnimation.playAnimation();
        statusText.setText("Scanning WiFi...");
        attachAnimationEndListener();
    }

    private void attachAnimationEndListener() {
        wifiAnimation.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                boolean isSecure = WiFiSecurityUtility.isWiFiSecure(MainActivity.this);
                boolean isVpnActive = isVpnInUse();
                Log.d("vpn", String.valueOf(isVpnActive));

                statusText.setText("Secure Scan Done");

                if (!WiFiSecurityUtility.isConnectedToWiFi(MainActivity.this)) {
                    securityStatus.setText("You are not connected to a WiFi network.");
                    securityStatus.setTextColor(Color.parseColor("#CB0404"));
                    return;
                }

                if (isVpnActive) {
                    securityStatus.setText("You are connected through a secure VPN. Your connection is well protected.");
                    securityStatus.setTextColor(Color.parseColor("#1E5128"));
                } else if (isSecure) {
                    securityStatus.setText("Your WiFi is secured with modern encryption protocols (WPA2/WPA3).");
                    securityStatus.setTextColor(Color.parseColor("#1E5128"));
                } else {
                    securityStatus.setText("Your WiFi is insecure or using outdated encryption like WEP/Open. Use VPN to stay protected.");
                    securityStatus.setTextColor(Color.parseColor("#8E1616"));
                }
            }
        });
    }
    private boolean isVpnInUse() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm != null) {
            Network[] networks = cm.getAllNetworks();
            for (Network network : networks) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                    return true;
                }
            }
        }
        return false;
    }

}
