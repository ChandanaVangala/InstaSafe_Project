package com.chandana.checkwifisecurity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.location.LocationManager;
import android.content.pm.PackageManager;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import java.util.List;

public class WiFiSecurityUtility {

    private static final String PERMISSION_FINE_LOCATION = android.Manifest.permission.ACCESS_FINE_LOCATION;

    public static boolean isWiFiSecure(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        if (wifiManager == null || !wifiManager.isWifiEnabled()) return false;

        NetworkInfo networkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
        if (networkInfo == null || !networkInfo.isConnected() || networkInfo.getType() != ConnectivityManager.TYPE_WIFI) return false;

        boolean isGpsEnabled = isGpsEnabled(context, locationManager);
        if (!isGpsEnabled) {
            showLocationSettingsDialog(context);
            return false;
        }

        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        if (wifiInfo == null) return false;

        return checkWiFiSecurity(context, wifiManager, wifiInfo);
    }

    private static boolean checkWiFiSecurity(Context context, WifiManager wifiManager, WifiInfo wifiInfo) {
        if (ActivityCompat.checkSelfPermission(context, PERMISSION_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return false;

        String ssid = wifiInfo.getSSID() != null ? wifiInfo.getSSID().replace("\"", "") : null;
        List<ScanResult> scanResults = wifiManager.getScanResults();

        for (ScanResult result : scanResults) {
            if (result.SSID != null && result.SSID.equals(ssid)) {
                return result.capabilities.contains("WPA") || result.capabilities.contains("WPA2") || result.capabilities.contains("WPA3");
            }
        }
        return false;
    }

    private static boolean isGpsEnabled(Context context, LocationManager locationManager) {
        if (locationManager == null || ActivityCompat.checkSelfPermission(context, PERMISSION_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    private static void showLocationSettingsDialog(Context context) {
        if (!(context instanceof android.app.Activity)) return;

        new AlertDialog.Builder(context)
                .setTitle("Enable Location Services")
                .setMessage("Please enable GPS to scan your WiFi device for potential threats.")
                .setPositiveButton("Settings", (dialog, which) -> {
                    context.startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .setCancelable(true)
                .show();
    }

    public static boolean isConnectedToWiFi(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected() && ni.getType() == ConnectivityManager.TYPE_WIFI;
        }
        return false;
    }
}
